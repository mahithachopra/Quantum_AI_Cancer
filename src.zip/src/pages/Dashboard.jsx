import Home from "./home";

export default function Dashboard() {
  return <Home />;
}